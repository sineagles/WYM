""" Parts of the U-Net model """

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""

    def __init__(self, in_channels, out_channels, mid_channels=None):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.double_conv(x)


class Down(nn.Module):
    """Downscaling with maxpool then double conv"""

    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels)
        )
        self.avgpool_conv = nn.Sequential(
            nn.AvgPool2d(2),  # 使用2x2平均池化层代替最大池化
            DoubleConv(in_channels, out_channels)
        )
        self.conv = nn.Conv2d(out_channels*2, out_channels, 1)

    def forward(self, x):
        x_1 = self.maxpool_conv(x)
        x_2 = self.avgpool_conv(x)
        # x = torch.cat([x_2, x_1], dim=1)
        # x = self.conv(x)
        x = x_1 * torch.softmax(x_2, dim=1) + x_1
        # return x_1
        return x
        # return x_2



class Up(nn.Module):
    """Upscaling then double conv"""

    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        self.scale = 4
        # if bilinear, use the normal convolutions to reduce the number of channels
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
            self.conv = DoubleConv(in_channels, out_channels, in_channels // 2)
        else:
            self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, kernel_size=2, stride=2)
            self.conv = DoubleConv(in_channels, out_channels)
        self.sccsa = SCCSA(in_channels, in_channels)

    def forward(self, x1, x2):
        x1 = self.up(x1)   #x1,x2  [4,128,24,32]
        # print(x1.size())
        # input is CHW
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]

        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])
        # if you have padding issues, see
        # https://github.com/HaiyongJiang/U-Net-Pytorch-Unstructured-Buggy/commit/0e854509c2cea854e247a9c615f175f76fbb2e3a
        # https://github.com/xiaopeng-liao/Pytorch-UNet/commit/8ebac70e633bac59fc22bb5195e513d5832fb3bd
        x = torch.cat([x2, x1], dim=1)  #1024
        # B, L, C = x.shape  #SCCA
        # x = x.view(B, int(math.sqrt(L)), int(math.sqrt(L)), C)  #SCCA
        # x = x.permute(0, 3, 1, 2)  #SCCA
        # print(x.size())  # 4,256,24,32

        x = self.sccsa(x)
        # x = x.flatten(2).transpose(1, 2)  #SCCA
        return self.conv(x)


class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)

class CAM_Module(nn.Module):
    """ Channel attention module"""
    def __init__(self, in_dim):
        super(CAM_Module, self).__init__()
        self.chanel_in = in_dim
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax  = nn.Softmax(dim=-1)
    def forward(self,x):
        # print(x.size())
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X C X C
        """
        m_batchsize, C, height, width = x.size()
        proj_query = x.view(m_batchsize, C, -1)
        proj_key = x.view(m_batchsize, C, -1).permute(0, 2, 1)
        energy = torch.bmm(proj_query, proj_key)
        energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy)-energy
        attention = self.softmax(energy_new)
        proj_value = x.view(m_batchsize, C, -1)

        out = torch.bmm(attention, proj_value)
        out = out.view(m_batchsize, C, height, width)

        out = self.gamma*out + x
        return out
class SCCSA(nn.Module):
    def __init__(self, in_channels, out_channels, rate=4):
        super(SCCSA, self).__init__()

        self.channel_attention = nn.Sequential(
                    nn.Linear(in_channels, int(in_channels / rate)),
                    nn.ReLU(inplace=True),
                    nn.Linear(int(in_channels / rate), in_channels)
                )
        # self.channel_attention = CAM_Module(in_channels)
        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, int(in_channels / rate), kernel_size=7, padding=3),
            nn.BatchNorm2d(int(in_channels / rate)),
            nn.ReLU(inplace=True),
            nn.Conv2d(int(in_channels / rate), out_channels, kernel_size=7, padding=3),
            nn.BatchNorm2d(out_channels)
        )

    # def forward(self, x):  CSA
    #     b, c, h, w = x.shape # 4,256,24,32
    #     # print(x.size())
    #     # x_permute = x.permute(0, 2, 3, 1).view(b, -1, c)
    #     # print(x_permute.size())  # 4,768,256
    #     x_permute = self.channel_attention(x)
    #     # print(x_permute.size())
    #     x_att_permute = x_permute.view(b, h, w, c)
    #     x_channel_att = x_att_permute.permute(0, 3, 1, 2)
    #     x = x * x_channel_att
    #     x_spatial_att = self.spatial_attention(x).sigmoid()
    #     out = x * x_spatial_att
    #     return out
    def forward(self, x):   # SSCA
        b, c, h, w = x.shape
        x_permute = x.permute(0, 2, 3, 1).view(b, -1, c)
        x_att_permute = self.channel_attention(x_permute).view(b, h, w, c)
        x_channel_att = x_att_permute.permute(0, 3, 1, 2)
        x = x * x_channel_att
        x_spatial_att = self.spatial_attention(x).sigmoid()
        out = x * x_spatial_att
        return out


class MRA(nn.Module):
    def __init__(self, c1_in_channels=64, c2_in_channels=128, c3_in_channels=256, embedding_dim=1024, drop_rate=0.2,
                 classes=2):
        super(MRA, self).__init__()
        self.conv_c1 = nn.Conv2d(in_channels=c1_in_channels, out_channels=embedding_dim, kernel_size=1)
        self.down_1 = nn.MaxPool2d(kernel_size=4, stride=4, padding=0, dilation=1)
        self.conv_c2 = nn.Conv2d(in_channels=c2_in_channels, out_channels=embedding_dim, kernel_size=1)
        self.down_2 = nn.MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(in_channels=embedding_dim * 3, out_channels=embedding_dim, kernel_size=1, padding=0, stride=1),
            nn.BatchNorm2d(embedding_dim),
            nn.GELU()
        )
        self.drop = nn.Dropout2d(drop_rate)
        # self.edge = DRA(in_ch=1024, class_num=classes)
        self.edge = DRA(in_ch=256, class_num=classes)


    def forward(self, inputs):
        c1, c2, c3 = inputs

        c1_ = self.conv_c1(c1)
        c1_ = self.down_1(c1_)

        c2_ = self.conv_c2(c2)
        c2_ = self.down_2(c2_)

        c3_ = c3

        c_fuse = self.conv_fuse(torch.cat([c1_, c2_, c3_], dim=1))
        x = self.drop(c_fuse) + self.edge(c2_, c1_) + self.edge(c3_, c2_)

        return x


class DRA(nn.Module):
    def __init__(self, in_ch=64, class_num=2, value=0.5, simple=1, large=0):
        super(DRA, self).__init__()
        self.threshold = value
        self.s_mode = simple
        self.l_mode = large
        self.sigmoid = nn.Sigmoid()
        self.add_learn = nn.Sequential(
            nn.Conv2d(in_channels=in_ch, out_channels=in_ch, kernel_size=1),
            nn.BatchNorm2d(in_ch),
            nn.GELU()
        )
        self.to_class_1 = nn.Conv2d(in_channels=in_ch, out_channels=class_num, kernel_size=1)
        self.to_class_2 = nn.Conv2d(in_channels=in_ch, out_channels=class_num, kernel_size=1)
        self.region_learn = nn.Sequential(
            nn.Conv2d(in_channels=class_num, out_channels=1, kernel_size=1),
            nn.BatchNorm2d(1),
            nn.GELU()
        )

    def forward(self, x1, x2):
        b, c, h, w = x1.shape
        if self.s_mode == 1:
            x1_in = 1 * (x1 > self.threshold)
            x2_in = 1 * (x2 > self.threshold)
            edge_diff = torch.abs(x1_in - x2_in)
            x = (edge_diff) * x1 + x1
            x = self.add_learn(x)
        elif self.l_mode == 1:
            x1_in = self.to_class_1(x1)
            x2_in = self.to_class_2(x2)
            x1_in = 1 * (x1_in > self.threshold)
            x2_in = 1 * (x2_in > self.threshold)
            edge_diff = torch.abs(x1_in - x2_in) * 1.000000
            edge_diff = self.region_learn(edge_diff)
            x = self.sigmoid(edge_diff) * x1 + x1
            x = self.add_learn(x)
        return x
