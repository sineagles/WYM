""" Full assembly of the parts to form the complete network """

from unet.unet_parts import *
import torch
from torch.utils.checkpoint import checkpoint
from unet.transformer_parts import Transformer_block_global, Transformer_block_local, Transformer_block
from einops import rearrange, repeat


class UNet(nn.Module):
    def __init__(self, n_channels, n_classes, imgsize=(224, 224),  bilinear=False, pretrained=False):
        super(UNet, self).__init__()
        if pretrained:
            self.resnet.load_state_dict(torch.load('pretrained/resnet34-333f7ec4.pth'))
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear
        self.scale = 4

        self.inc = (DoubleConv(n_channels, 64// self.scale))
        self.down1 = (Down(64// self.scale, 128// self.scale))
        self.down2 = (Down(128// self.scale, 256// self.scale))
        self.down3 = (Down(256// self.scale, 512// self.scale))
        factor = 2 if bilinear else 1
        self.down4 = (Down(512// self.scale, 1024 // factor// self.scale))
        # self.down4 = (Down(512, 512 // factor))

        self.up1 = (Up(1024// self.scale, 512 // factor// self.scale, bilinear))
        # self.up1 = (Up(512, 512 // factor, bilinear))

        self.up2 = (Up(512// self.scale, 256 // factor// self.scale, bilinear))
        self.up3 = (Up(256// self.scale, 128 // factor// self.scale, bilinear))
        self.up4 = (Up(128// self.scale, 64// self.scale, bilinear))
        self.outc = (OutConv(64// self.scale, n_classes))
        self.head = MRA(c1_in_channels=256// self.scale, c2_in_channels=512// self.scale, c3_in_channels=1024// self.scale, embedding_dim=1024// self.scale,
                        classes=n_classes)
        self.toshow_bi = nn.Identity()
        self.trans_global = Transformer_block_global(256 // factor // self.scale, 256 // factor // self.scale * 2, imgsize[0] // 4, imgsize[1] // 4, 1,
                                         heads=4, patch_size=1)
        self.convl3 = nn.Conv2d(256 // factor // self.scale * 2, 64 // self.scale * 4, kernel_size=1, padding=0,
                                bias=False)

        self.outc3 = OutConv(64 // self.scale * 4, n_classes)
        self.outc2 = OutConv(64 // self.scale * 4, n_classes)
        self.softmax = nn.Softmax(dim=1)
        self.trans_local2 = Transformer_block_local(128 // self.scale // factor, 128 // self.scale // factor * 2, imgsize[0] // 2, imgsize[1] // 2, 1,
                                        heads=6, patch_size=1, n_classes=n_classes, win_size=16)
        self.convl2 = nn.Conv2d(128 // factor // self.scale * 2, 64 // self.scale * 4, kernel_size=1, padding=0,
                                bias=False)
        self.outc2 = OutConv(64 // self.scale * 4, n_classes)

        self.convl1 = nn.Conv2d(64 // self.scale, 64 // self.scale * 4, kernel_size=1, padding=0, bias=False)
        self.outc1 = OutConv(64 // self.scale * 4, n_classes)
        self.out = OutConv(3 * 64 // self.scale * 4, n_classes)
    def forward(self, x):
        # print(x.size())
        input_for_head = []
        # print(x.size())   #[4, 3, 192, 256]
        x1 = self.inc(x)  # [4, 16, 192, 256]
        # print(x1.size())
        x2 = self.down1(x1)  # [4, 32, 96, 128]
        # print(x2.size())

        x3 = self.down2(x2)  # [4, 64, 48, 64]
        input_for_head.append(x3)
        # print(x3.size())

        x4 = self.down3(x3)   # [4, 128, 24, 32]
        input_for_head.append(x4)
        # print(x4.size())

        x5 = self.down4(x4)   # [4, 256, 12, 16]
        input_for_head.append(x5)
        # print(x5.size())

        # bottle
        b = self.head(input_for_head)
        b = self.toshow_bi(b)
        # print(b.size())   # 4,256,12,16
        # print(x4.size())   # 4,128,24,32

        # d4 = self.up1(b, x4)   # 8c
        d4 = self.up1(x5, x4)
        # print(d4.size())

        d3 = self.up2(d4, x3)   # 4c
        # print(d3.size())
        d2 = self.up3(d3, x2)
        d1 = self.up4(d2, x1)

        # logits = self.outc(d1)
        # return logits
        # print(b.size())

        trans_global = self.trans_global(b, d4, d3)
        l3 = self.convl3(trans_global)

        pred3 = self.outc3(l3)  # b c h w
        l3_up = l3[:, :, :, :, None].repeat(1, 1, 1, 1, 16)
        l3_up = rearrange(l3_up, 'b c h w (m n) -> b c (h m) (w n)', m=4, n=4)

        pred3_p = self.softmax(pred3)
        trans_local2 = self.trans_local2(d2, pred3_p)
        l2 = self.convl2(trans_local2)

        # pred2 = self.outc2(l2)  # b c h w
        l2_up = l2[:, :, :, :, None].repeat(1, 1, 1, 1, 4)
        l2_up = rearrange(l2_up, 'b c h w (m n) -> b c (h m) (w n)', m=2, n=2)


        l1 = self.convl1(d1)
        predf = torch.cat((l1, l2_up, l3_up), dim=1)
        predf = self.out(predf)

        return predf

    def use_checkpointing(self):
        self.inc = torch.utils.checkpoint(self.inc)
        self.down1 = torch.utils.checkpoint(self.down1)
        self.down2 = torch.utils.checkpoint(self.down2)
        self.down3 = torch.utils.checkpoint(self.down3)
        self.down4 = torch.utils.checkpoint(self.down4)
        self.up1 = torch.utils.checkpoint(self.up1)
        self.up2 = torch.utils.checkpoint(self.up2)
        self.up3 = torch.utils.checkpoint(self.up3)
        self.up4 = torch.utils.checkpoint(self.up4)
        self.outc = torch.utils.checkpoint(self.outc)