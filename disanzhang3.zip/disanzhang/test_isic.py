import torch
import torch.nn.functional as F
import numpy as np
import os, argparse
# from lib.TransFuse import TransFuse_S, TransFuse_L, TransFuse_L_384
# from lib.ERDUnet import ERDUnet
# from lib.ERSUnet import ERSUnet
from unet.unet_model import UNet
from utils.dataloader import test_dataset
import imageio

from medpy import metric



# def sensitivity_socre(output, target):
# # #     return metric.binary.sensitivity(torch.sigmoid(output).data.cpu().numpy() > 0.5, target.data.cpu().numpy() > 0.5)
import numpy as np
from thop import profile

def count_parameters(model):
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params / 1e6  # 转换为M(兆)为单位

def calculate_flops(model, input_shape):
    input_data = torch.randn(input_shape)
    flops, params = profile(model, inputs=(input_data.cuda(),))
    return flops, params/ 1e6
def recall_score(output, target, threshold=0.5):
    """
    计算召回率(Recall)
    """
    output_binary = (output > threshold).astype(np.float32)
    target_binary = (target > threshold).astype(np.float32)

    tp = np.sum(np.logical_and(output_binary == 1, target_binary == 1))
    fn = np.sum(np.logical_and(output_binary == 0, target_binary == 1))

    recall = tp / (tp + fn)

    return recall

def sensitivity_score(y_pred, y_true, threshold=0.5):
    """
    计算灵敏度（Sensitivity/True Positive Rate）通过 NumPy

    :param y_true: 真实的标签，形状为 (batch_size, height, width) 的 NumPy 数组
    :param y_pred: 预测的标签，形状为 (batch_size, height, width) 的 NumPy 数组
    :param threshold: 用于将预测值二值化的阈值
    :return: 灵敏度值
    """
    # 首先将预测值二值化
    y_pred_binary = (y_pred > threshold).astype(np.float32)

    # 计算真正例（TP）和假负例（FN）
    tp = np.sum(np.logical_and(y_true == 1, y_pred_binary == 1))
    fn = np.sum(np.logical_and(y_true == 1, y_pred_binary == 0))

    # 避免除以零的情况
    if (tp + fn) == 0:
        return 0.0

        # 计算灵敏度（真正例率）
    sensitivity = tp / (tp + fn)

    return sensitivity




# def specificity_socre(output, target):
# #     return metric.binary.specificity(torch.sigmoid(output).data.cpu().numpy()> 0.5, target.data.cpu().numpy()> 0.5)
# # # precision =ppv
# # def precision_socre(output, target):
# #     return metric.binary.precision(torch.sigmoid(output).data.cpu().numpy()> 0.5, target.data.cpu().numpy()> 0.5)
# # # Jaccard Coefficient
# # def jaccard_socre(output, target):
# #     return metric.binary.jc(torch.sigmoid(output).data.cpu().numpy()> 0.5, target.data.cpu().numpy()> 0.5)
import numpy as np


# def dice_score(output, target, threshold=0.5):
# #     """
# #     计算 Dice 系数
# #     """
# #     output_binary = (output > threshold).astype(np.float32)
# #     target_binary = (target > threshold).astype(np.float32)
# #
# #     intersection = np.sum(output_binary * target_binary)
# #     union = np.sum(output_binary) + np.sum(target_binary)
# #
# #     smooth = 1e-7  # 避免除以零
# #     dice = (2 * intersection + smooth) / (union + smooth)
# #
# #     return dice


def specificity_score(output, target, threshold=0.5):
    """
    计算特异度（Specificity）
    """
    output_binary = (output > threshold).astype(np.float32)
    target_binary = (target > threshold).astype(np.float32)

    tn = np.sum(np.logical_and(output_binary == 0, target_binary == 0))
    fp = np.sum(np.logical_and(output_binary == 1, target_binary == 0))

    specificity = tn / (tn + fp)

    return specificity


def precision_score(output, target, threshold=0.5):
    """
    计算精确度（Precision）或正预测值（PPV）
    """
    output_binary = (output > threshold).astype(np.float32)
    target_binary = (target > threshold).astype(np.float32)

    tp = np.sum(np.logical_and(output_binary == 1, target_binary == 1))
    fp = np.sum(np.logical_and(output_binary == 1, target_binary == 0))

    precision = tp / (tp + fp)

    return precision


# def jaccard_score(output, target, threshold=0.5):
#     """
#     计算 Jaccard 系数（也称为 Intersection over Union, IoU）
#     """
#     return dice_score(output, target, threshold)  # 因为 Jaccard 系数和 Dice 系数是一样的

def mean_iou_np(y_true, y_pred, **kwargs):
    """
    compute mean iou for binary segmentation map via numpy
    """
    axes = (0, 1)
    intersection = np.sum(np.abs(y_pred * y_true), axis=axes)
    mask_sum = np.sum(np.abs(y_true), axis=axes) + np.sum(np.abs(y_pred), axis=axes)
    union = mask_sum - intersection

    smooth = .001
    iou = (intersection + smooth) / (union + smooth)
    return iou


def mean_dice_np(y_true, y_pred, **kwargs):
    """
    compute mean dice for binary segmentation map via numpy
    """
    axes = (0, 1) # W,H axes of each image
    intersection = np.sum(np.abs(y_pred * y_true), axis=axes)
    mask_sum = np.sum(np.abs(y_true), axis=axes) + np.sum(np.abs(y_pred), axis=axes)

    smooth = .001
    dice = 2*(intersection + smooth)/(mask_sum + smooth)
    return dice



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--ckpt_path', type=str, default='D:/wch/TransFuse-main/snapshots/ours-2018-1e-3/unet-65.pth')
    parser.add_argument('--test_path', type=str,
                        default='D:/wch/TransFuse-HRNet/data/ISIC2018/', help='path to test dataset')
                        # default='D:/wch/TransFuse-main/data/ISIC2017/', help='path to test dataset')

    parser.add_argument('--save_path', type=str, default=None, help='path to save inference segmentation')

    opt = parser.parse_args()

    # model = TransFuse_S().cuda()
    # model = ERSUnet().cuda()
    model = UNet(n_channels=3, n_classes=1, pretrained=False).cuda()

    model.load_state_dict(torch.load(opt.ckpt_path), strict=False)
    model.cuda()
    model.eval()

    if opt.save_path is not None:
        os.makedirs(opt.save_path, exist_ok=True)

    print('evaluating model: ', opt.ckpt_path)

    image_root = '{}/data_test.npy'.format(opt.test_path)
    gt_root = '{}/mask_test.npy'.format(opt.test_path)
    test_loader = test_dataset(image_root, gt_root)

    dice_bank = []
    iou_bank = []
    acc_bank = []
    sen_bank = []
    spec_bank = []
    # jac_bank = []
    pre_bank = []

    for i in range(test_loader.size):
        image, gt = test_loader.load_data()
        gt = 1*(gt>0.5)
        image = image.cuda()

        with torch.no_grad():
             res = model(image)

        res = res.sigmoid().data.cpu().numpy().squeeze()
        res = 1*(res > 0.5)

        if opt.save_path is not None:
            imageio.imwrite(opt.save_path+'/'+str(i)+'_pred.jpg', res)
            imageio.imwrite(opt.save_path+'/'+str(i)+'_gt.jpg', gt)

        dice = mean_dice_np(gt, res)
        iou = mean_iou_np(gt, res)
        acc = np.sum(res == gt) / (res.shape[0]*res.shape[1])
        sen = sensitivity_score(res, gt)
        spec = specificity_score(res, gt)
        # jac = jaccard_socre(res, gt)
        pre = precision_score(res, gt)

        # loss_bank.append(loss.item())
        dice_bank.append(dice)
        iou_bank.append(iou)
        acc_bank.append(acc)
        sen_bank.append(sen)
        spec_bank.append(spec)
        # jac_bank.append(jac)
        pre_bank.append(pre)

        # acc_bank.append(acc)
        # dice_bank.append(dice)
        # iou_bank.append(iou)
    #
    # print('Dice: {:.4f}, IoU: {:.4f}, Acc: {:.4f}'.
    #     format(np.mean(dice_bank), np.mean(iou_bank), np.mean(acc_bank)))
    print('Dice: {:.4f}, IoU: {:.4f}, Acc: {:.4f}, Sensitivity: {:.4f}, '
              'Specificity: {:.4f}, Precision: {:.4f}'.
              format(np.mean(dice_bank), np.mean(iou_bank), np.mean(acc_bank),
                     np.mean(sen_bank), np.mean(spec_bank), np.mean(pre_bank)))
