import numpy as np
import cv2
# import os
import os
import re

# # 输入图片文件夹路径
# input_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1-2_Training_Input'
# # 输出图片文件夹路径
# output_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1-2_Training_Input_Renamed'
# # 地面真值图片文件夹路径
# gt_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Training_GroundTruth'
#
# # 创建输出文件夹
# os.makedirs(output_dir, exist_ok=True)
#
# # 获取所有输入图片文件名
# input_files = sorted(os.listdir(input_dir))
#
# # 遍历所有输入图片文件
# for i, filename in enumerate(input_files):
#     # 获取原始文件名中的数字部分
#     num = re.findall(r'\d+', filename)[0]
#
#     # 构造新文件名
#     new_filename = 'ISIC_' + str(i).zfill(7) + '.jpg'
#
#     # 复制并重命名输入图片
#     os.rename(os.path.join(input_dir, filename), os.path.join(output_dir, new_filename))
#
#     # 查找对应的地面真值图片
#     gt_filename = [f for f in os.listdir(gt_dir) if num in f]
#
#     # 如果找到对应的地面真值图片
#     if gt_filename:
#         # 构造新的地面真值图片名
#         new_gt_filename = 'ISIC_' + str(i).zfill(7) + '_segmentation.png'
#
#         # 重命名地面真值图片
#         os.rename(os.path.join(gt_dir, gt_filename[0]), os.path.join(gt_dir, new_gt_filename))
#
# print('图片重命名完成!')


# input_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1-2_Validation_Input'
# # 输出图片文件夹路径
# output_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Validation_Input_Renamed'
# # 地面真值图片文件夹路径
# gt_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Validation_GroundTruth'
#
# # 创建输出文件夹
# os.makedirs(output_dir, exist_ok=True)
#
# # 获取所有输入图片文件名
# input_files = sorted(os.listdir(input_dir))
#
# # 设置起始序号
# start_index = 2594
#
# # 遍历所有输入图片文件
# for i, filename in enumerate(input_files, start=start_index):
#     # 获取原始文件名中的数字部分
#     num = re.findall(r'\d+', filename)[0]
#
#     # 构造新文件名
#     new_filename = 'ISIC_' + str(i).zfill(7) + '.jpg'
#
#     # 复制并重命名输入图片
#     os.rename(os.path.join(input_dir, filename), os.path.join(output_dir, new_filename))
#
#     # 查找对应的地面真值图片
#     gt_filename = [f for f in os.listdir(gt_dir) if num in f]
#
#     # 如果找到对应的地面真值图片
#     if gt_filename:
#         # 构造新的地面真值图片名
#         new_gt_filename = 'ISIC_' + str(i).zfill(7) + '_segmentation.png'
#
#         # 重命名地面真值图片
#         os.rename(os.path.join(gt_dir, gt_filename[0]), os.path.join(gt_dir, new_gt_filename))
#
# print('图片重命名完成!')
# 输入图片文件夹路径
# input_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1-2_Test_Input'
# # 输出图片文件夹路径
# output_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Test_Input_Renamed'
# # 地面真值图片文件夹路径
# gt_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Test_GroundTruth'
#
# # 创建输出文件夹
# os.makedirs(output_dir, exist_ok=True)
#
# # 获取所有输入图片文件名
# input_files = sorted(os.listdir(input_dir))
#
# # 设置起始序号
# start_index = 2694
#
# # 遍历所有输入图片文件
# for i, filename in enumerate(input_files, start=start_index):
#     # 获取原始文件名中的数字部分
#     num = re.findall(r'\d+', filename)[0]
#
#     # 构造新文件名
#     new_filename = 'ISIC_' + str(i).zfill(7) + '.jpg'
#
#     # 复制并重命名输入图片
#     os.rename(os.path.join(input_dir, filename), os.path.join(output_dir, new_filename))
#
#     # 查找对应的地面真值图片
#     gt_filename = [f for f in os.listdir(gt_dir) if num in f]
#
#     # 如果找到对应的地面真值图片
#     if gt_filename:
#         # 构造新的地面真值图片名
#         new_gt_filename = 'ISIC_' + str(i).zfill(7) + '_segmentation.png'
#
#         # 重命名地面真值图片
#         os.rename(os.path.join(gt_dir, gt_filename[0]), os.path.join(gt_dir, new_gt_filename))
#
# print('图片重命名完成!')
# import os
# import re
#
#
root = 'D:/wch/TransFuse-HRNet/data/ISIC2018/' # change to your data folder path
data_f = ['ISIC2018_Task1-2_Training_Input/', 'ISIC2018_Task1-2_Validation_Input/', 'ISIC2018_Task1-2_Test_Input/']
mask_f = ['ISIC2018_Task1_Training_GroundTruth/', 'ISIC2018_Task1_Validation_GroundTruth/', 'ISIC2018_Task1_Test_GroundTruth/']
set_size = [2594, 100, 1000]
save_name = ['train', 'val', 'test']
# root = 'D:/wch/TransFuse-main/data/ISIC2017/' # change to your data folder path
# data_f = ['ISIC-2017_Training_Data/', 'ISIC-2017_Validation_Data/', 'ISIC-2017_Test_v2_Data/']
# mask_f = ['ISIC-2017_Training_Part1_GroundTruth/', 'ISIC-2017_Validation_Part1_GroundTruth/', 'ISIC-2017_Test_v2_Part1_GroundTruth/']
# set_size = [2000, 150, 600]
# save_name = ['train', 'val', 'test']
# root = 'D:/wch/TransFuse-main/data/ISIC2016/' # change to your data folder path
# data_f = ['ISIC2016_ISIC_Part1_Training_Data/', 'ISIC2016_ISIC_Part1_Test_Data/']
# mask_f = ['ISIC2016_ISIC_Part1_Training_GroundTruth/', 'ISIC2016_ISIC_Part1_Test_GroundTruth/']
# set_size = [900, 379]
# save_name = ['train', 'test']

height = 192 # 384
width = 256 # 512

for j in range(3):

	print('processing ' + data_f[j] + '......')
	count = 0
	length = set_size[j]
	imgs = np.uint8(np.zeros([length, height, width, 3]))
	masks = np.uint8(np.zeros([length, height, width]))

	path = root + data_f[j]
	mask_p = root + mask_f[j]

	for i in os.listdir(path):
		if len(i.split('_'))==2:
			img = cv2.imread(path+i)
			img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
			img = cv2.resize(img, (width, height))

			m_path = mask_p + i.replace('.jpg', '_segmentation.png')
			mask = cv2.imread(m_path, 0)
			mask = cv2.resize(mask, (width, height))

			imgs[count] = img
			masks[count] = mask

			count +=1
			print(count)


	np.save('{}/data_{}.npy'.format(root, save_name[j]), imgs)
	np.save('{}/mask_{}.npy'.format(root, save_name[j]), masks)
	# print(masks.size())
# import os
# import shutil
#
# # 输入图像文件夹路径
# input_dir_val = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Validation_Input_Renamed'
# input_dir_test = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Test_Input_Renamed'
#
# # 输出图像文件夹路径
# output_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1-2_Training_Input_Renamed'
#
# # 地面真值文件夹路径
# gt_dir_val = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Validation_GroundTruth'
# gt_dir_test = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Test_GroundTruth'
# gt_output_dir = 'D:/wch/TransFuse-main/data/ISIC2018/ISIC2018_Task1_Training_GroundTruth'
#
# # 移动验证集图像
# for filename in os.listdir(input_dir_val):
#     src_path = os.path.join(input_dir_val, filename)
#     dst_path = os.path.join(output_dir, filename)
#     shutil.move(src_path, dst_path)
#
# # 移动测试集图像
# for filename in os.listdir(input_dir_test):
#     src_path = os.path.join(input_dir_test, filename)
#     dst_path = os.path.join(output_dir, filename)
#     shutil.move(src_path, dst_path)
#
# # 移动验证集地面真值
# for filename in os.listdir(gt_dir_val):
#     src_path = os.path.join(gt_dir_val, filename)
#     dst_path = os.path.join(gt_output_dir, filename)
#     shutil.move(src_path, dst_path)
#
# # 移动测试集地面真值
# for filename in os.listdir(gt_dir_test):
#     src_path = os.path.join(gt_dir_test, filename)
#     dst_path = os.path.join(gt_output_dir, filename)
#     shutil.move(src_path, dst_path)
#
# print('文件移动完成!')