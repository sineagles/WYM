import cv2
import torch
from torch.autograd import Variable
import argparse
from datetime import datetime
# from lib.TransFuse import TransFuse_S, TransFuse_L, TransFuse_L_384
# from model.hrnet import HighResolutionNet
from utils.dataloader import get_loader, test_dataset
from utils.utils import AvgMeter
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from test_isic import mean_dice_np, mean_iou_np, sensitivity_score, specificity_score, precision_score, recall_score,calculate_flops,count_parameters
import os
from albumentations import Compose
import sys
from unet.unet_model import UNet
from common.logging import get_logger

# logger = get_logger(filename='ISIC2018', dir='D:/wch/TransFuse-main/UNet-log/')
logger = get_logger(filename='ISIC2018', dir='D:/wch/disanzhang/test-log/')

# logger = get_logger(filename='ISIC2017', dir='D:/wch/TransFuse-main/UNet-log/')

def structure_loss(pred, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(pred, mask, reduction='none')
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))

    pred = torch.sigmoid(pred)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)
    return (wbce + wiou).mean()


# 改
def train(train_loader, model, optimizer, epoch, best_Iou, best_Dice, best_Acc, best_Sen, best_Spec, best_Pre, best_Recal):
    model.train()
    loss_record = AvgMeter()
    accum = 0
    # best_Iou = 0.0
    for i, pack in enumerate(train_loader, start=1):
        # ---- data prepare ----
        images, gts = pack
        images = Variable(images).cuda()

        # gts = F.interpolate(gts, size=(48,64), mode='bilinear', align_corners=False)
        # gts = np.array(gts)
        # gts = cv2.resize(gts, (96, 128))
        gts = Variable(gts).cuda()

        # ---- forward ----
        lateral_map = model(images)

        # ---- loss function ----
        loss = structure_loss(lateral_map, gts)

        # ---- backward ----
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), opt.grad_norm)
        optimizer.step()
        optimizer.zero_grad()

        # ---- recording loss ----
        # loss_record2.update(loss2.data, opt.batchsize)
        # loss_record3.update(loss3.data, opt.batchsize)
        loss_record.update(loss.data, opt.batchsize)

        # ---- train visualization ----
        if i % 20 == 0 or i == total_step:
            logger.info('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
                  '[ loss: {:0.4f}]'.
                  format(datetime.now(), epoch, opt.epoch, i, total_step,
                         loss_record.show()))

    save_path = 'test/{}/'.format(opt.train_save)
    os.makedirs(save_path, exist_ok=True)

    if (epoch + 1) % 1 == 0:
        # meanloss = test(model, opt.test_path)
        # if meanloss < best_loss:
        #     print('new best loss: ', meanloss)
        #     best_loss = meanloss
        meanIou, meanDice, meanAcc, meanSen, meanSpec, meanPre, meanRecal = test(model, opt.test_path)

        if meanIou > best_Iou and meanDice > best_Dice and meanAcc > best_Acc\
                and meanSen> best_Sen and meanSpec> best_Spec and meanPre > best_Pre and meanRecal > best_Recal:
            # print('new best IoU: ', meanIou)
            best_Iou = meanIou
            best_Dice = meanDice
            best_Acc = meanAcc
            best_Sen = meanSen
            best_Spec = meanSpec
            best_Pre = meanPre
            best_Recal = meanRecal
            # torch.save(model.state_dict(), save_path + 'unet-%dbest.pth' % epoch)
            # ('[Saving Snapshot:]', save_path + 'unet-%dbest.pth' % epoch)
            torch.save(model.state_dict(), save_path + 'test-{}.pth'.format(epoch))
            print('[Saving Snapshot:]', save_path + 'test-{}.pth'.format(epoch))

        # torch.save(model.state_dict(), save_path + 'unet-{}.pth'.format(epoch))
        # print('[Saving Snapshot:]', save_path + 'unet-{}.pth'.format(epoch))
    return best_Iou, best_Dice, best_Acc, best_Sen, best_Spec, best_Pre, best_Recal


def test(model, path):
    model.eval()
    # mean_loss = []
    mean_Iou = []
    mean_Dice = []
    mean_Acc = []
    mean_sen = []
    mean_spec = []
    # mean_jac = []
    mean_pre = []
    mean_Recal = []

    for s in ['val', 'test']:
    # for s in ['test']:
        image_root = '{}/data_{}.npy'.format(path, s)
        gt_root = '{}/mask_{}.npy'.format(path, s)
        test_loader = test_dataset(image_root, gt_root)

        dice_bank = []
        iou_bank = []
        loss_bank = []
        acc_bank = []
        sen_bank = []
        spec_bank = []
        # jac_bank = []
        pre_bank = []
        rec_bank = []

        for i in range(test_loader.size):
            image, gt = test_loader.load_data()
            image = image.cuda()

            with torch.no_grad():
                res = model(image)
            # gt_resized = torch.nn.functional.interpolate(torch.tensor(gt).unsqueeze(0).unsqueeze(0).float(),
            #                                              size=(res.shape[2], res.shape[3]), mode='bilinear',
            #                                              align_corners=False)
            # gt_resized = 1 * (gt_resized > 0.5)  # 将插值后的结果二值化
            loss = structure_loss(res, torch.tensor(gt).unsqueeze(0).unsqueeze(0).cuda())
            # loss = structure_loss(res, gt_resized.cuda())

            res = res.sigmoid().data.cpu().numpy().squeeze()
            gt = 1 * (gt > 0.5)
            res = 1 * (res > 0.5)

            dice = mean_dice_np(gt, res)
            iou = mean_iou_np(gt, res)
            acc = np.sum(res == gt) / (res.shape[0] * res.shape[1])
            sen = sensitivity_score(res, gt)
            spec = specificity_score(res, gt)
            # jac = jaccard_socre(res, gt)
            pre = precision_score(res, gt)
            rec = recall_score(res, gt)

            loss_bank.append(loss.item())
            dice_bank.append(dice)
            iou_bank.append(iou)
            acc_bank.append(acc)
            sen_bank.append(sen)
            spec_bank.append(spec)
            # jac_bank.append(jac)
            pre_bank.append(pre)
            rec_bank.append(rec)

        logger.info('{} Loss: {:.4f}, Dice: {:.4f}, IoU: {:.4f}, Acc: {:.4f}, Sensitivity: {:.4f}, '
              'Specificity: {:.4f}, Precision: {:.4f}, Recal: {:.4f}'.
              format(s, np.mean(loss_bank), np.mean(dice_bank), np.mean(iou_bank), np.mean(acc_bank),
                     np.mean(sen_bank), np.mean(spec_bank), np.mean(pre_bank), np.mean(rec_bank)
                     ))

        # mean_loss.append(np.mean(loss_bank))
        mean_Iou.append(np.mean(iou_bank))
        mean_Dice.append(np.mean(dice_bank))
        mean_Acc.append(np.mean(acc_bank))
        mean_sen.append(np.mean(sen_bank))
        mean_spec.append(np.mean(spec_bank))
        # mean_Acc.append(np.mean(jac_bank))
        mean_pre.append(np.mean(pre_bank))
        mean_Recal.append(np.mean(rec_bank))

    # return mean_loss[0]
    return mean_Iou[0], mean_Dice[0], mean_Acc[0], mean_sen[0], mean_spec[0], mean_pre[0], mean_Recal[0]


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int, default=100, help='epoch number')
    parser.add_argument('--lr', type=float, default=1e-3, help='learning rate')
    parser.add_argument('--batchsize', type=int, default=8, help='training batch size')
    parser.add_argument('--grad_norm', type=float, default=2.0, help='gradient clipping norm')
    parser.add_argument('--train_path', type=str,
                        default='D:/wch/TransFuse-HRNet/data/ISIC2018/', help='path to train dataset')
                        # default='D:/wch/TransFuse-main/data/ISIC2017/', help='path to train dataset')
                        # default='D:/wch/TransFuse-main/data/ISIC2016/', help='path to train dataset')

    parser.add_argument('--test_path', type=str,
                        default='D:/wch/TransFuse-HRNet/data/ISIC2018/', help='path to test dataset')
                        # default='D:/wch/TransFuse-main/data/ISIC2017/', help='path to test dataset')
                        # default='D:/wch/TransFuse-main/data/ISIC2016/', help='path to test dataset')

    parser.add_argument('--train_save', type=str, default='test')
    parser.add_argument('--beta1', type=float, default=0.5, help='beta1 of adam optimizer')
    parser.add_argument('--beta2', type=float, default=0.999, help='beta2 of adam optimizer')

    opt = parser.parse_args()

    # ---- build models ----
    # model = TransFuse_S(pretrained=False).cuda()
    model = UNet(n_channels=3, n_classes=1, pretrained=False).cuda()
    torch.cuda.empty_cache()
    params = model.parameters()
    optimizer = torch.optim.Adam(params, opt.lr, betas=(opt.beta1, opt.beta2))
    num_parameters = count_parameters(model)
    input_shape = (8, 3, 224,224)
    # 计算FLOPs
    flops, params = calculate_flops(model, input_shape)

    # transform = Compose([],is_check_shapes=False)
    image_root = '{}/data_train.npy'.format(opt.train_path)
    gt_root = '{}/mask_train.npy'.format(opt.train_path)

    train_loader = get_loader(image_root, gt_root, batchsize=opt.batchsize)
    total_step = len(train_loader)

    logger.info("#" * 20, "Start Training", "#" * 20)
    # 打印参数信息到日志
    logger.info("Parameters:")
    logger.info(f"  --epoch: {opt.epoch}")
    logger.info(f"Number of parameters: {num_parameters:.2f} M")
    logger.info(f"FLOPs: {flops / 1e9:.2f} GFLOPs")
    # logger.info(f"Number of parameters: {params}")
    logger.info(f"  --lr: {opt.lr}")
    logger.info(f"  --batchsize: {opt.batchsize}")
    logger.info(f"  --grad_norm: {opt.grad_norm}")
    logger.info(f"  --train_path: {opt.train_path}")
    logger.info(f"  --test_path: {opt.test_path}")
    logger.info(f"  --train_save: {opt.train_save}")
    logger.info(f"  --beta1: {opt.beta1}")
    logger.info(f"  --beta2: {opt.beta2}")
    logger.info("")  # 打印修改的模块

    best_loss = 1e5
    best_Iou = 0.0
    best_Dice = 0.0
    best_Acc = 0.0
    best_Sen = 0.0
    best_Spec = 0.0
    best_Pre = 0.0
    best_Recal = 0.0

    for epoch in range(1, opt.epoch + 1):
        best_Iou, best_Dice, best_Acc, best_Sen, best_Spec, best_Pre, best_Recal = train(train_loader, model, optimizer, epoch, best_Iou, best_Dice, best_Acc, best_Sen, best_Spec, best_Pre, best_Recal)
    # log_file_path = os.path.join('snapshots', opt.train_save, 'logfile.txt')
    # os.makedirs(os.path.dirname(log_file_path), exist_ok=True)
    # sys.stdout = open(log_file_path, 'w', encoding='utf-8')
    # if not os.path.exists(log_file_path):
    #     open(log_file_path, 'w').close()
    # sys.stdout = open(log_file_path, 'w', encoding='utf-8')

    # sys.stdout = sys.__stdout__
